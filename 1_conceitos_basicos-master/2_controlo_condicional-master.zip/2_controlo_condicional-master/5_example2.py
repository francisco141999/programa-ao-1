"""
Example 2
"""

student_name = "Student 1"
is_student = False
if student_name == "Student 1" \
    or student_name == "Student 2" \
    or student_name == "Student 3":
    is_student = True
print(is_student)
