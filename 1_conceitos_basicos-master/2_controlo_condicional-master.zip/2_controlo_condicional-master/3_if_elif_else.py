"""
if elif else
"""

NUMBER = 17
value = int(input("input a value: "))

if value == NUMBER:
    print("Winner!!!")
elif value > NUMBER:
    print("your number is greater")
else:
    print("your number is lower")
    