"""
Example 3
"""

student = "Student 1"
students = ["Student 1", "Student 2", "Student 3"]
if student in students:
    print("{} is a student".format(student))
else:
    print("{} is not a student".format(student))
