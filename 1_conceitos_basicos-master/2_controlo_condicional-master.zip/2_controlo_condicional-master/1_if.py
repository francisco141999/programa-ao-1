"""
if
"""

NUMBER = 17
value = int(input("input a value: "))

if value == NUMBER:
    print("Winner!!!")
    
print("Game over...")
