"""
from import
"""

from math import sqrt

print(sqrt(25))

print(dir())
