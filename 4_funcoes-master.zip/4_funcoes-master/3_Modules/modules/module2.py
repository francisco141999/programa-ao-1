"""
Module example
"""

def print_lines(character, qty):
    print(character * qty)
