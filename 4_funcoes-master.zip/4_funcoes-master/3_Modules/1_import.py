"""
import
See: https://www.blog.pythonlibrary.org/2016/03/01/python-101-all-about-imports/
"""

import math

print(math.sqrt(25))

print(dir())
