"""
Import module example
"""

from modules import module1
from modules import module2

print(module1.my_sum(1.25, 3.2))
print(module1.daddy())
print(module1.some_value)

module2.print_lines("-", 10)
module2.print_lines("*", 10)