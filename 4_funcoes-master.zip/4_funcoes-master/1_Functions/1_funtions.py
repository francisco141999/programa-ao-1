"""
Funtions 
"""

MAX = 4

def print_line():
    print("-" * 30)

print_line()
print_line()
print_line()
print_line()

for _ in range(MAX):
    print_line()