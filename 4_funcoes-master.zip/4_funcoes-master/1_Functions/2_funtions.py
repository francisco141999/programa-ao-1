"""
Funtions and empty blocks (pass)
"""

def say_hello():
    print("Hello!!")
   
def test():
    """I will implement this function later..."""
    pass

say_hello()
say_hello()
test()
say_hello()
