"""
abs
"""

values = [10, 11, 15, 36]

value = min(values) - max(values)
print(value)
print(abs(value))

print()
value = max(values) - min(values)
print(value)
print(abs(value))
