"""
len
- Sized: str, list, dict, range, tuple, set, bytes 
"""

item = "Student 1"
print(len(item))

items = [10, 2, 25]
print(len(items))
