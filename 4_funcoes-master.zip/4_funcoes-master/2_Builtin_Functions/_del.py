"""
del
"""

name = "Student 1"
print(name)

del name       # delete variable
print(name)    # Error: cannot access to A
