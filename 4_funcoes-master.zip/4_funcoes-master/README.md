![ESTG](https://www.estg.ipp.pt/logo-ipp.png)

# Funções e Recursividade

* Funções
* Parâmetros
* Escopo da variáveis
* Módulos
* Recursividade
