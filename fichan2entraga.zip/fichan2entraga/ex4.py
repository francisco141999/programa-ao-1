numero = int(input ("Introduza um numero: "))

if numero % 3  and  numero % 5  :
    print("Sao divisiveis por 3 e 5")
else:
    print("Nao sao divisiveis por 3 e 5")

