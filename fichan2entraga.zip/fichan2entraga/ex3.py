numero =int(input ("Introduza um numero: "))

if numero % 2 == 0 :
 print("É par ")
else:
  print("É impar")  